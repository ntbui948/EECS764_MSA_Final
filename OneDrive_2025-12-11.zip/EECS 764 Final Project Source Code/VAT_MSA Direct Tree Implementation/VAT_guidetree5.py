#!/usr/bin/env python3
import argparse
import subprocess
import numpy as np
from scipy.cluster.hierarchy import linkage, to_tree
from scipy.spatial.distance import squareform
import os
from Bio import SeqIO
import time

# CONFIG
FASTA_FILE = "PF00029_seed.fasta"
OUTPUT_DIR = "vat_progressive_msa"
THREADS = 16
IS_DNA = False
os.makedirs(OUTPUT_DIR, exist_ok=True)

class TreeNode:
    def __init__(self, node_id, seq_indices=None, left=None, right=None):
        self.id = node_id
        self.seq_indices = seq_indices if seq_indices is not None else []
        self.left = left
        self.right = right

    def is_leaf(self):
        return self.left is None and self.right is None


# Creating the distance matrix based on VAT pairwise alignments
def run_vat_pairwise(fasta_file, is_dna=IS_DNA, threads=THREADS):
    """
    Run VAT in a batch alignment of all sequences
    Produces a full NxN distance matrix.
    """

    # Load FASTA
    seq_records = list(SeqIO.parse(fasta_file, "fasta"))
    seq_ids = [rec.id for rec in seq_records]
    n = len(seq_ids)

    # Initialize distance matrix
    dist_matrix = np.full((n, n), 1.0, dtype=float)
    np.fill_diagonal(dist_matrix, 0.0)

    # Build VAT database from ALL sequences
    db_type = "nucl" if is_dna else "prot"
    db_name = os.path.join(OUTPUT_DIR, "vat_db_batch")

    subprocess.run([
        "VAT", "makevatdb",
        "--in", fasta_file,
        "--dbtype", db_type,
        "-d", db_name
    ], check=True)

    # Output file containing *all* alignments
    output_path = os.path.join(OUTPUT_DIR, "vat_batch_output.txt")

    # ONE VAT RUN — query is the entire FASTA file
    cmd = [
        "VAT",
        "dna" if is_dna else "protein",
        "-d", db_name,
        "-q", fasta_file,
        "-o", output_path,
        "-f", "tab",
        "-p", str(threads),
        "-S", "100",
        "-e", "100",
        "--report_id", "0",
        "--SEN"
    ]
    subprocess.run(cmd, check=True)

    id_to_idx = {seq_id: i for i, seq_id in enumerate(seq_ids)}

    # helper: clean VAT IDs
    def norm(raw):
        if raw in id_to_idx:
            return raw
        if "/" in raw:
            base = raw.split("/")[0]
            if base in id_to_idx:
                return base
        return None

    # Parse ALL alignments from VAT batch run
    with open(output_path) as fh:
        for line in fh:
            if not line.strip() or line.startswith("@"):
                continue

            parts = line.split("\t")
            if len(parts) < 3:
                continue

            qid, sid = norm(parts[0]), norm(parts[1])
            if qid is None or sid is None:
                continue

            # --- FILTER OUT SELF-HITS ---
            if qid == sid:
                continue

            q = id_to_idx[qid]
            s = id_to_idx[sid]

            try:
                pct_id = float(parts[2]) / 100.0
            except:
                continue

            dist = 1.0 - pct_id
            dist_matrix[q, s] = dist
            dist_matrix[s, q] = dist

    print("VAT distance matrix created.")
    return dist_matrix, seq_ids

def build_full_guide_tree(dist_matrix):
    """
    Build a complete UPGMA guide tree directly from the full VAT distance matrix.
    """

    n = dist_matrix.shape[0]
    condensed = squareform(dist_matrix)
    Z = linkage(condensed, method="average")
    scipy_root, _ = to_tree(Z, rd=True)

    # recursively convert SciPy nodes into our guide tree nodes
    def convert(node, next_id):
        if node.is_leaf():
            leaf_id = node.id
            return TreeNode(node_id=leaf_id, seq_indices=[leaf_id]), next_id
        left, next_id = convert(node.left, next_id)
        right, next_id = convert(node.right, next_id)
        internal = TreeNode(node_id=next_id,
                            seq_indices=left.seq_indices + right.seq_indices,
                            left=left, right=right)
        return internal, next_id + 1

    root, _ = convert(scipy_root, n)
    return root


# need to convert tree to newick format for inputting into ClustalO (only to use the HHAlign package from the tool)
def tree_to_newick(node, seq_ids):
    if node.is_leaf():
        return seq_ids[node.id]
    left = tree_to_newick(node.left, seq_ids)
    right = tree_to_newick(node.right, seq_ids)
    return f"({left},{right})"


if __name__ == "__main__":

    print("\nBuilding VAT distance matrix...")
    t0 = time.time()
    dist_matrix, seq_ids = run_vat_pairwise(FASTA_FILE)
    t1 = time.time()
    print(f"VAT matrix created in {t1 - t0:.2f} seconds")

    print("\nBuilding guide tree from VAT distance matrix (UPGMA)...")
    gt_start = time.time()
    root = build_full_guide_tree(dist_matrix)
    gt_end = time.time()
    print(f"Full guide-tree creation took {gt_end - gt_start:.2f} seconds")

    newick = tree_to_newick(root, seq_ids) + ";"
    out_path = os.path.join(OUTPUT_DIR, "guide_tree.nwk")

    with open(out_path, "w") as f:
        f.write(newick)

    print(f"\nGuide tree written to: {out_path}")
    print("Done.")

    print("aligned MSA file has been outputted to aligned_sequences.fasta")
    aligned_file = os.path.join(OUTPUT_DIR, "aligned_sequences.fasta")
    guide_tree_file= os.path.join(OUTPUT_DIR, "guide_tree.nwk")

    # running ClustalO with our own guide tree as input so it can do profile-profile alignment
    subprocess.run([
        "clustalo",
        "-i", FASTA_FILE,
        "--guidetree-in", guide_tree_file,
        "-o", aligned_file,
        "--force",
        "--outfmt", "fasta"
    ], check=True)

