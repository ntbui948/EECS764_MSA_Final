#!/usr/bin/env python3
import argparse
import subprocess
import numpy as np
from scipy.cluster.hierarchy import linkage, to_tree
from scipy.spatial.distance import squareform
import os
from Bio import SeqIO
import time

# CONFIG
FASTA_FILE = "PF00019_seed.fasta"
OUTPUT_DIR = "vat_progressive_msa"
THREADS = 4
IS_DNA = False
os.makedirs(OUTPUT_DIR, exist_ok=True)

class TreeNode:
    """
    Simple tree node that preserves original sequence indices.
    Makes it so that the tree building function knows which index belongs to which sequence.
    """
    def __init__(self, node_id, seq_indices=None, left=None, right=None):
        self.id = node_id
        self.seq_indices = seq_indices if seq_indices is not None else []
        self.left = left
        self.right = right

    def is_leaf(self):
        return self.left is None and self.right is None


def run_vat_pairwise(fasta_file, is_dna=IS_DNA, threads=THREADS):
    """
    Run VAT to compute pairwise distance matrix by iterating
    each sequence as a query against a single VAT database.
    """

    # read sequences
    seq_records = list(SeqIO.parse(fasta_file, "fasta"))
    seq_ids = [rec.id for rec in seq_records]
    n = len(seq_ids)

    # initialize distance matrix
    dist_matrix = np.full((n, n), 1.0, dtype=float)
    np.fill_diagonal(dist_matrix, 0.0)

    # build VAT database from ALL sequences
    db_type = "nucl" if is_dna else "prot"
    db_name = os.path.join(OUTPUT_DIR, "vat_db_iter")
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    cmd_make_db = [
        "VAT", "makevatdb",
        "--in", fasta_file,
        "--dbtype", db_type,
        "-d", db_name,
    ]
    subprocess.run(cmd_make_db, check=True)

    # mapping from IDs to indices (FASTA order)
    id_to_index = {seq_id: i for i, seq_id in enumerate(seq_ids)}

    # converting the parsed id of the sequence back to the actual FASTA name
    def normalize_id(raw):
        if raw in id_to_index:
            return raw
        if "/" in raw:
            base = raw.split("/")[0]
            if base in id_to_index:
                return base
        base = raw.split()[0]
        if base in id_to_index:
            return base
        return None

    # iterate each sequence as its own query
    for q_idx, rec in enumerate(seq_records):
        query_id = rec.id
        print(f"Running VAT for query {q_idx + 1}/{n}: {query_id}")

        # write this single query sequence to a temporary FASTA
        tmp_query = os.path.join(OUTPUT_DIR, f"vat_query_{q_idx}.fa")
        with open(tmp_query, "w") as fh:
            SeqIO.write(rec, fh, "fasta")

        # output file for the single query
        output_path = os.path.join(OUTPUT_DIR, f"vat_pairwise_{q_idx}.txt")

        # run VAT
        cmd_align = [
            "VAT",
            "dna" if is_dna else "protein",
            "-d", db_name,
            "-q", tmp_query,
            "-o", output_path,
            "-f", "tab",
            "-p", str(threads),
            "-S", "100",
            "-e", "100",
            "--xdrop", "50",
            "--report_id", "0",
        ]
        subprocess.run(cmd_align, check=True)

        current_query_idx = q_idx
        current_subject_idx = None

        # parse this query's VAT output
        with open(output_path) as fh:
            for raw in fh:
                line = raw.strip()
                if not line:
                    continue

                # skip all lines that aren't the actual sequences
                if line.startswith("@"):
                    continue

                # splitting output lines using tab delimitation so we can get information about identity
                parts = line.split("\t")

                # skip any malformed or short lines
                if len(parts) < 3:
                    continue

                # the first two columns are the Query and Subject sequence names
                qid, sid = parts[0], parts[1]

                # make sure that the names are normalized to the original FASTA names
                qid = normalize_id(qid)
                sid = normalize_id(sid)
                if qid is None or sid is None:
                    continue

                q = id_to_index[qid]
                s = id_to_index[sid]

                # calculating identity
                try:
                    pct_identity = float(parts[2]) / 100.0
                except:
                    continue

                # adding the distance to the matrix
                dist = 1.0 - pct_identity
                dist_matrix[q, s] = dist
                dist_matrix[s, q] = dist

        # clean up temp files
        os.remove(tmp_query)
        os.remove(output_path)

    print("Distance matrix shape:", dist_matrix.shape)
    print("Min distance:", np.min(dist_matrix))
    print("Max distance:", np.max(dist_matrix))
    print("Number of sequences with only max distances:",
          np.sum(np.all(dist_matrix == 1.0, axis=1)))

    return dist_matrix, seq_ids

def build_full_guide_tree(dist_matrix):
    """
    Build a complete UPGMA guide tree directly from the full VAT distance matrix.
    """

    n = dist_matrix.shape[0]
    condensed = squareform(dist_matrix)
    Z = linkage(condensed, method="average")
    scipy_root, _ = to_tree(Z, rd=True)

    # recursively convert SciPy nodes into our guide tree nodes
    def convert(node, next_id):
        if node.is_leaf():
            leaf_id = node.id
            return TreeNode(node_id=leaf_id, seq_indices=[leaf_id]), next_id
        left, next_id = convert(node.left, next_id)
        right, next_id = convert(node.right, next_id)
        internal = TreeNode(node_id=next_id,
                            seq_indices=left.seq_indices + right.seq_indices,
                            left=left, right=right)
        return internal, next_id + 1

    root, _ = convert(scipy_root, n)
    return root


# need to convert tree to newick format for inputting into ClustalO (only to use the HHAlign package from the tool)
def tree_to_newick(node, seq_ids):
    if node.is_leaf():
        return seq_ids[node.id]
    left = tree_to_newick(node.left, seq_ids)
    right = tree_to_newick(node.right, seq_ids)
    return f"({left},{right})"


if __name__ == "__main__":

    print("\nBuilding VAT distance matrix...")
    t0 = time.time()
    dist_matrix, seq_ids = run_vat_pairwise(FASTA_FILE)
    t1 = time.time()
    print(f"VAT matrix created in {t1 - t0:.2f} seconds")

    print("\nBuilding guide tree from VAT distance matrix (UPGMA)...")
    gt_start = time.time()
    root = build_full_guide_tree(dist_matrix)
    gt_end = time.time()
    print(f"Full guide-tree creation took {gt_end - gt_start:.2f} seconds")

    newick = tree_to_newick(root, seq_ids) + ";"
    out_path = os.path.join(OUTPUT_DIR, "guide_tree.nwk")

    with open(out_path, "w") as f:
        f.write(newick)

    print(f"\nGuide tree written to: {out_path}")
    print("Done.")

    print("aligned MSA file has been outputted to aligned_sequences.fasta")
    aligned_file = os.path.join(OUTPUT_DIR, "aligned_sequences.fasta")
    guide_tree_file= os.path.join(OUTPUT_DIR, "guide_tree.nwk")

    # running ClustalO with our own guide tree as input so it can do profile-profile alignment
    subprocess.run([
        "clustalo",
        "-i", FASTA_FILE,
        "--guidetree-in", guide_tree_file,
        "-o", aligned_file,
        "--force",
        "--outfmt", "fasta"
    ], check=True)

