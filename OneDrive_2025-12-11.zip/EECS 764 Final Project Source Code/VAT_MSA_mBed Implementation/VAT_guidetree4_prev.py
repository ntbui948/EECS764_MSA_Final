#!/usr/bin/env python3
import argparse
import subprocess
import numpy as np
from scipy.cluster.hierarchy import linkage, to_tree
from scipy.spatial.distance import squareform
import os
from Bio import SeqIO
import re
import time
from sklearn.cluster import KMeans
from sklearn.cluster import BisectingKMeans as SklearnBisectingKMeans


# CONFIG
FASTA_FILE = "PF00029_seed.fasta" # input file containing all sequences
OUTPUT_DIR = "vat_progressive_msa" # directory for working
THREADS = 4
MAX_CLUSTER_SIZE = 35
IS_DNA = False
os.makedirs(OUTPUT_DIR, exist_ok=True)

DB_NAME = os.path.join(OUTPUT_DIR, "vat_db")
DB_TYPE = "nucl" if IS_DNA else "prot"
OUTPUT_PATH = os.path.join(OUTPUT_DIR, "vat_pairwise.txt")


class TreeNode:
    """
    Simple tree node that preserves original sequence indices.
    Makes it so that the tree building function knows which index belongs to which sequence.
    """
    def __init__(self, node_id, seq_indices=None, left=None, right=None):
        self.id = node_id
        self.seq_indices = seq_indices if seq_indices is not None else []
        self.left = left
        self.right = right

    def is_leaf(self):
        return self.left is None and self.right is None

def run_vat_pairwise(fasta_file, is_dna=IS_DNA, threads=THREADS):
    """
    Run VAT to compute pairwise distance matrix by iterating
    each sequence as a query against a single VAT database.
    """

    # read sequences
    seq_records = list(SeqIO.parse(fasta_file, "fasta"))
    seq_ids = [rec.id for rec in seq_records]
    n = len(seq_ids)

    # initialize distance matrix
    dist_matrix = np.full((n, n), 1.0, dtype=float)
    np.fill_diagonal(dist_matrix, 0.0)

    # build VAT database from ALL sequences
    db_type = "nucl" if is_dna else "prot"
    db_name = os.path.join(OUTPUT_DIR, "vat_db_iter")
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    cmd_make_db = [
        "VAT", "makevatdb",
        "--in", fasta_file,
        "--dbtype", db_type,
        "-d", db_name,
    ]
    subprocess.run(cmd_make_db, check=True)

    # mapping from IDs to indices (FASTA order)
    id_to_index = {seq_id: i for i, seq_id in enumerate(seq_ids)}

    # converting the parsed id of the sequence back to the actual FASTA name
    def normalize_id(raw):
        if raw in id_to_index:
            return raw
        if "/" in raw:
            base = raw.split("/")[0]
            if base in id_to_index:
                return base
        base = raw.split()[0]
        if base in id_to_index:
            return base
        return None

    # iterate each sequence as its own query
    for q_idx, rec in enumerate(seq_records):
        query_id = rec.id
        print(f"Running VAT for query {q_idx + 1}/{n}: {query_id}")

        # write this single query sequence to a temporary FASTA
        tmp_query = os.path.join(OUTPUT_DIR, f"vat_query_{q_idx}.fa")
        with open(tmp_query, "w") as fh:
            SeqIO.write(rec, fh, "fasta")

        # output file for the single query
        output_path = os.path.join(OUTPUT_DIR, f"vat_pairwise_{q_idx}.txt")

        # run VAT
        cmd_align = [
            "VAT",
            "dna" if is_dna else "protein",
            "-d", db_name,
            "-q", tmp_query,
            "-o", output_path,
            "-f", "tab",
            "-p", str(threads),
            "-S", "100",
            "-e", "100",
            "--xdrop", "50",
            "--report_id", "0",
        ]
        subprocess.run(cmd_align, check=True)

        current_query_idx = q_idx
        current_subject_idx = None

        # parse this query's VAT output
        with open(output_path) as fh:
            for raw in fh:
                line = raw.strip()
                if not line:
                    continue

                # skip all lines that aren't the actual sequences
                if line.startswith("@"):
                    continue

                # splitting output lines using tab delimitation so we can get information about identity
                parts = line.split("\t")
                
                # skip any malformed or short lines
                if len(parts) < 3:
                    continue

                # the first two columns are the Query and Subject sequence names
                qid, sid = parts[0], parts[1]

                # make sure that the names are normalized to the original FASTA names
                qid = normalize_id(qid)
                sid = normalize_id(sid)
                if qid is None or sid is None:
                    continue

                q = id_to_index[qid]
                s = id_to_index[sid]

                # calculating identity
                try:
                    pct_identity = float(parts[2]) / 100.0
                except:
                    continue

                # adding the distance to the matrix
                dist = 1.0 - pct_identity
                dist_matrix[q, s] = dist
                dist_matrix[s, q] = dist
                
        # clean up temp files
        os.remove(tmp_query)
        os.remove(output_path)

    print("Distance matrix shape:", dist_matrix.shape)
    print("Min distance:", np.min(dist_matrix))
    print("Max distance:", np.max(dist_matrix))
    print("Number of sequences with only max distances:",
          np.sum(np.all(dist_matrix == 1.0, axis=1)))

    return dist_matrix, seq_ids

# computing number of reference sequences to use for mBed
def compute_n_refs(n_sequences):
    return int(min(max(20, 2 * np.log2(n_sequences)), 50))
seq_count = sum(1 for _ in SeqIO.parse(FASTA_FILE, "fasta"))
N_REFS = compute_n_refs(seq_count)

def select_reference_indices_farthest(dist_matrix, n_refs=N_REFS, random_state=0):
    """
    Pick n_refs reference sequences that are well spread out in the VAT distance space
    using a farthest-point heuristic.
    """
    rng = np.random.RandomState(random_state)
    dist_matrix = np.asarray(dist_matrix, dtype=float)

    n = dist_matrix.shape[0]
    n_refs = max(2, min(n_refs, n))

    first = rng.randint(0, n)
    refs = [first]

    # determining reference sequences based on furthest distance from all reference sequences currently added
    while len(refs) < n_refs:
        min_dists = np.min(dist_matrix[:, refs], axis=1)
        min_dists[refs] = -1.0
        next_idx = int(np.argmax(min_dists))
        if next_idx in refs:
            break
        refs.append(next_idx)

    return refs


def mbed_embedding_from_vat(dist_matrix, n_refs=N_REFS, random_state=0):
    """
    Build an mBed-style embedding from a VAT distance matrix.
    Each sequence is represented as a vector of distances to selected reference
    sequences. Columns are standardized.
    """
    dist_matrix = np.asarray(dist_matrix, dtype=float)
    n = dist_matrix.shape[0]

    ref_indices = select_reference_indices_farthest(
        dist_matrix, n_refs=n_refs, random_state=random_state
    )
    ref_indices = np.array(ref_indices, dtype=int)

    # embedding into a distance vector based on distances to reference sequences
    X = dist_matrix[:, ref_indices].astype(float)

    col_means = X.mean(axis=0)
    col_stds = X.std(axis=0)
    col_stds[col_stds == 0.0] = 1.0
    X = (X - col_means) / col_stds

    return X, ref_indices

# clustering sequences
def sklearn_bisecting_kmeans_embed(X, max_cluster_size=MAX_CLUSTER_SIZE, random_state=0):
    """
    Use scikit-learn's BisectingKMeans to cluster the embedding.
    https://scikit-learn.org/stable/modules/generated/sklearn.cluster.BisectingKMeans.html
    """
    n_samples = X.shape[0]
    n_clusters = max(1, int(np.ceil(float(n_samples) / float(max_cluster_size))))

    bk = SklearnBisectingKMeans(
        n_clusters=n_clusters,
        random_state=random_state,
    )
    labels = bk.fit_predict(X)
    centers = bk.cluster_centers_

    # iterate and get list of clusters and cluster centers for UPGMA to build the guide tree with
    clusters = []
    centers_list = []
    for k in range(n_clusters):
        idx = np.where(labels == k)[0]
        if idx.size == 0:
            continue
        clusters.append(idx)
        centers_list.append(centers[k])

    if not clusters:
        clusters = [np.arange(n_samples)]
        centers_list = [X.mean(axis=0)]

    centers_arr = np.vstack(centers_list)
    return clusters, centers_arr

# building subtrees for each cluster to be put into the final guide tree
def _build_upgma_subtree(indices, dist_matrix, next_internal_id_start):
    """
    Build a UPGMA tree for a subset of sequence indices using the original
    VAT distance matrix.
    """
    indices = list(indices)
    n_sub = len(indices)

    if n_sub == 1:
        idx = indices[0]
        return TreeNode(node_id=idx, seq_indices=[idx]), next_internal_id_start

    if n_sub == 2:
        i0, i1 = indices
        left = TreeNode(node_id=i0, seq_indices=[i0])
        right = TreeNode(node_id=i1, seq_indices=[i1])
        root = TreeNode(node_id=next_internal_id_start,
                        seq_indices=[i0, i1],
                        left=left, right=right)
        return root, next_internal_id_start + 1

    sub_dist = dist_matrix[np.ix_(indices, indices)].copy()
    np.fill_diagonal(sub_dist, 0.0)
    condensed = squareform(sub_dist)
    # creating tree using UPGMA
    linkage_matrix = linkage(condensed, method="average")
    scipy_root, _ = to_tree(linkage_matrix, rd=True)

    # adding actual sequences to the tree
    def convert(node, next_id):
        if node.is_leaf():
            seq_idx = indices[node.id]
            return TreeNode(node_id=seq_idx, seq_indices=[seq_idx]), next_id
        left_node, next_id = convert(node.left, next_id)
        right_node, next_id = convert(node.right, next_id)
        internal = TreeNode(node_id=next_id,
                            seq_indices=left_node.seq_indices + right_node.seq_indices,
                            left=left_node, right=right_node)
        return internal, next_id + 1

    return convert(scipy_root, next_internal_id_start)


def build_guide_tree_from_vat(dist_matrix, max_cluster_size=MAX_CLUSTER_SIZE, n_refs=N_REFS, random_state=0):
    """
    Build an mBed-style guide tree from a VAT distance matrix.
    Steps:
      1. Build an mBed embedding from VAT distances.
      2. Cluster sequences in embedding space via sklearn's BisectingKMeans.
      3. For each cluster, build a local UPGMA tree using the original VAT distances.
      4. Use cluster centers in embedding space to build a higher-level UPGMA tree.
      5. Replace cluster leaves in the cluster-center tree with the local subtrees.
    """
    dist_matrix = np.asarray(dist_matrix, dtype=float)
    n = dist_matrix.shape[0]

    # mBed embedding from VAT distances
    X_embed, ref_indices = mbed_embedding_from_vat(
        dist_matrix, n_refs=n_refs, random_state=random_state
    )

    # clustering in embedding space
    clusters, cluster_centers = sklearn_bisecting_kmeans_embed(
        X_embed,
        max_cluster_size=max_cluster_size,
        random_state=random_state,
    )

    # building subtrees with UPGMA
    cluster_trees = []
    next_internal_id = n
    for clust in clusters:
        if len(clust) == 0:
            continue
        subtree, next_internal_id = _build_upgma_subtree(
            clust, dist_matrix, next_internal_id
        )
        cluster_trees.append(subtree)

    if len(cluster_trees) == 1:
        return cluster_trees[0]

    # constructing full guide tree using UPGMA
    n_clusters = len(cluster_trees)
    cluster_centers = cluster_centers[:n_clusters]
    center_means = cluster_centers.mean(axis=0)
    center_stds = cluster_centers.std(axis=0)
    center_stds[center_stds == 0] = 1.0
    cluster_centers = (cluster_centers - center_means) / center_stds
    cluster_dist = np.zeros((n_clusters, n_clusters), dtype=float)
    for i in range(n_clusters):
        for j in range(i + 1, n_clusters):
            d = np.linalg.norm(cluster_centers[i] - cluster_centers[j])
            cluster_dist[i, j] = cluster_dist[j, i] = d
    np.fill_diagonal(cluster_dist, 0.0)

    condensed_clusters = squareform(cluster_dist)
    linkage_matrix = linkage(condensed_clusters, method="average")
    scipy_root, _ = to_tree(linkage_matrix, rd=True)

    cluster_id_to_tree = {i: cluster_trees[i] for i in range(n_clusters)}

    def build_final(node):
        nonlocal next_internal_id
        if node.is_leaf():
            return cluster_id_to_tree[node.id]
        left = build_final(node.left)
        right = build_final(node.right)
        internal = TreeNode(node_id=next_internal_id,
                            seq_indices=left.seq_indices + right.seq_indices,
                            left=left, right=right)
        next_internal_id += 1
        return internal

    return build_final(scipy_root)

# need to convert tree to newick format for inputting into ClustalO (only to use the HHAlign package from the tool)
def tree_to_newick(node, seq_ids):
    if node.is_leaf():
        return seq_ids[node.id]
    left = tree_to_newick(node.left, seq_ids)
    right = tree_to_newick(node.right, seq_ids)
    return f"({left},{right})"

if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Build VAT-based guide tree and run ClustalO MSA."
    )
    args = parser.parse_args()

    print("\nStarting VAT distance matrix creation...")
    t0 = time.time()

    dist_matrix, seq_ids = run_vat_pairwise(FASTA_FILE)

    t1 = time.time()
    print(f"VAT matrix created in {t1 - t0:.2f} seconds")

    print("\nStarting full guide-tree creation...")
    gt_start = time.time()

    root = build_guide_tree_from_vat(dist_matrix)

    gt_end = time.time()
    print(f"Full guide-tree creation took {gt_end - gt_start:.2f} seconds")

    newick_str = tree_to_newick(root, seq_ids) + ";"
    guide_tree_file = os.path.join(OUTPUT_DIR, "guide_tree.nwk")
    with open(guide_tree_file, "w") as f:
        f.write(newick_str)

    print("aligned MSA file has been outputted to aligned_sequences.fasta")
    aligned_file = os.path.join(OUTPUT_DIR, "aligned_sequences.fasta")

    # running ClustalO with our own guide tree as input so it can do profile-profile alignment
    subprocess.run([
        "clustalo",
        "-i", FASTA_FILE,
        "--guidetree-in", guide_tree_file,
        "-o", aligned_file,
        "--force",
        "--outfmt", "fasta"
    ], check=True)
