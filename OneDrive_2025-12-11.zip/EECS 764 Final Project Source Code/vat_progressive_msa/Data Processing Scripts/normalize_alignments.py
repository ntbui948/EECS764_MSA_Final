#!/usr/bin/env python3
from Bio import SeqIO
import re
import sys

pfam_seed = sys.argv[1]
predicted = sys.argv[2]

out_ref = "ref_normalized.fasta"
out_pred = "pred_normalized.fasta"

def read_pfam_seed(filename):
    """
    Reading seed file from Pfam and reformat it to match our alignment format
    """
    sequences = {}
    current_id = None
    current_seq = []

    with open(filename) as f:
        for line in f:
            line = line.rstrip()

            # skip empty or consensus lines
            if not line or line.startswith("#") or "/" not in line:
                continue

            m = re.match(r"^(\S+)\s+([A-Za-z\-\.]+)", line)
            if not m:
                continue

            seq_id = m.group(1)
            seq_part = m.group(2).replace(".", "-")

            if seq_id not in sequences:
                sequences[seq_id] = []

            sequences[seq_id].append(seq_part)

    # join multi-line blocks into one aligned string
    for sid in sequences:
        sequences[sid] = "".join(sequences[sid])

    return sequences


def read_fasta_alignment(filename):
    """
    Reads predicted aligned fasta but converts '.' gaps to '-' if that is necessary
    """
    seqs = {}
    for record in SeqIO.parse(filename, "fasta"):
        seqs[record.id] = str(record.seq).replace(".", "-")
    return seqs


# main
pfam_sequences = read_pfam_seed(pfam_seed)
pred_sequences = read_fasta_alignment(predicted)

ref_ids = set(pfam_sequences.keys())
pred_ids = set(pred_sequences.keys())

missing_in_pred = ref_ids - pred_ids
missing_in_ref = pred_ids - ref_ids

if missing_in_pred:
    print("Sequences missing from prediction:", missing_in_pred)
if missing_in_ref:
    print("Sequences missing from PFAM seed:", missing_in_ref)

common_ids = sorted(ref_ids & pred_ids)
print(f"Using {len(common_ids)} matching sequences.")

# normalize lengths by right-padding shorter sequences
pfam_len = max(len(pfam_sequences[sid]) for sid in common_ids)
pred_len = max(len(pred_sequences[sid]) for sid in common_ids)

# for strict comparison, we use the longer one
target_len = max(pfam_len, pred_len)

def right_pad(seq, L):
    if len(seq) >= L:
        return seq
    return seq + ("-" * (L - len(seq)))

for sid in common_ids:
    pfam_sequences[sid] = right_pad(pfam_sequences[sid], target_len)
    pred_sequences[sid] = right_pad(pred_sequences[sid], target_len)

# write normalized alignment files
with open(out_ref, "w") as out:
    for sid in common_ids:
        out.write(f">{sid}\n{pfam_sequences[sid]}\n")

with open(out_pred, "w") as out:
    for sid in common_ids:
        out.write(f">{sid}\n{pred_sequences[sid]}\n")

print("\nNormalized files written:")
print(out_ref)
print(out_pred)
