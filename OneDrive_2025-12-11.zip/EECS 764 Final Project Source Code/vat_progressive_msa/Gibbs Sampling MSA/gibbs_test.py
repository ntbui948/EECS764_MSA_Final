import random
import math
from collections import Counter, defaultdict

def compute_background_freq(sequences, alphabet, exclude_windows=None):
    """
    Computing background frequencies of each residue for all sequences
    """
    counts = Counter()
    total = 0

    for k, seq in enumerate(sequences):
        n = len(seq)
        ex_start, ex_W = None, None
        if exclude_windows is not None and k in exclude_windows:
            ex_start, ex_W = exclude_windows[k]

        for i, c in enumerate(seq):
            if c not in alphabet:
                continue

            if ex_start is not None and ex_start <= i < ex_start + ex_W:
                continue
            counts[c] += 1
            total += 1

    alpha = 1.0
    denom = total + alpha * len(alphabet)
    p = {}
    for a in alphabet:
        p[a] = (counts[a] + alpha) / denom
    return p


def compute_pattern_freq(sequences, starts, W, alphabet, exclude_index=None):
    """
    Extracts W length window from each sequence based on start positions for each sequence
    Computing the profile based on residue frequencies of each motif window
    """

    counts = [Counter() for _ in range(W)]
    used_sequences = 0

    # extracting motif windows of length W and count residue frequencies
    for k, seq in enumerate(sequences):
        if exclude_index is not None and k == exclude_index:
            continue

        start = starts[k]
        window = seq[start:start + W]
        if len(window) < W:
            continue

        used_sequences += 1
        for i, c in enumerate(window):
            if c not in alphabet:
                continue
            counts[i][c] += 1


    alpha = 1.0
    q = []
    for i in range(W):
        col_total = sum(counts[i][a] for a in alphabet)
        denom = col_total + alpha * len(alphabet)
        qi = {}
        for a in alphabet:
            qi[a] = (counts[i][a] + alpha) / denom
        q.append(qi)
    return q

# score a candidate window using log-odds sum
def window_log_odds(window, q, p):
    score = 0.0
    for i, c in enumerate(window):
        if c not in p:
            continue
        score += math.log(q[i][c] / p[c])
    return score


def gibbs_motif_sampler(sequences, W, iterations=2000, burn_in=500, seed=1):
    """
    Does Gibbs sampling and determines the best shared motif of width W between all sequences
    """
    random.seed(seed)

    N = len(sequences)
    if N == 0:
        raise ValueError("No sequences provided")
    alphabet = sorted({c for s in sequences for c in s})

    # each sequence is given a random motif starting position initially
    starts = []
    for s in sequences:
        if len(s) < W:
            raise ValueError("Sequence shorter than motif width W")
        starts.append(random.randint(0, len(s) - W))

    # compute initial background frequencies
    p_global = compute_background_freq(sequences, alphabet)

    # compute initial pattern frequencies to make an initial profile
    q = compute_pattern_freq(sequences, starts, W, alphabet)

    # computes wellness score of the pattern/motif after each iteration
    def compute_F(q_, p_):
        F = 0.0
        for i in range(W):
            for a in alphabet:
                qi = q_[i][a]
                if qi <= 0.0:
                    continue
                F += qi * math.log(qi / p_[a])
        return F

    best_starts = starts[:]
    best_q = [col.copy() for col in q]
    best_F = compute_F(q, p_global)

    # Gibbs sampling iterations
    for it in range(iterations):
        for z in range(N):
            # excluding sequence z temporarily and then recomputing background and profile frequencies
            exclude_windows = {k: (starts[k], W) for k in range(N) if k != z}
            p = compute_background_freq(sequences, alphabet, exclude_windows)
            q = compute_pattern_freq(sequences, starts, W, alphabet, exclude_index=z)

            seq = sequences[z]
            Lz = len(seq)

            # compute log-odds for each possible window of sequence z
            log_probs = []
            positions = []
            for x in range(0, Lz - W + 1):
                window = seq[x:x + W]
                positions.append(x)
                log_probs.append(window_log_odds(window, q, p))

            if not positions:
                continue

            # converting log-odds to probabilities: A_x / sum A_i
            max_log = max(log_probs)
            weights = [math.exp(lp - max_log) for lp in log_probs]
            total_w = sum(weights)
            weights = [w / total_w for w in weights]

            # sampling a new window start position for sequence z
            r = random.random()
            cum = 0.0
            new_start = positions[-1]
            for pos, w in zip(positions, weights):
                cum += w
                if r <= cum:
                    new_start = pos
                    break
            starts[z] = new_start

        # after each iteration, recompute profile and motif score
        q = compute_pattern_freq(sequences, starts, W, alphabet)
        F = compute_F(q, p_global)

        if it >= burn_in and F > best_F:
            best_F = F
            best_starts = starts[:]
            best_q = [col.copy() for col in q]

    return best_starts, best_q, best_F

if __name__ == "__main__":
    import sys

    if len(sys.argv) < 3:
        print("Usage: python gibbs_test.py <pfam_fasta> <motif_width>")
        sys.exit(1)

    # user specifies input sequences file and the desired motif window length
    fasta_file = sys.argv[1]
    W = int(sys.argv[2])

    # load sequences
    sequences = []
    names = []

    with open(fasta_file) as f:
        seq = []
        name = None
        for line in f:
            line = line.strip()
            if not line:
                continue
            if line.startswith(">"):
                if seq:
                    sequences.append("".join(seq).replace("-", ""))
                    seq = []
                name = line[1:]
                names.append(name)
            else:
                seq.append(line)
        if seq:
            sequences.append("".join(seq).replace("-", ""))

    print(f"Loaded {len(sequences)} Pfam sequences.")
    print(f"Motif width W = {W}")

    # run Gibbs sampler
    starts, q, F = gibbs_motif_sampler(
        sequences,
        W,
        iterations=2000, # number of iterations can be altered based on dataset
        burn_in=500,
        seed=42
    )

    # print motif start positions
    print("\n Motif Start Positions: ")
    for name, st in zip(names, starts):
        print(f"{name}: start = {st}")

    # extract and output motif alignment
    print("\n Motif Alignment (ungapped)")
    for name, seq, st in zip(names, sequences, starts):
        motif = seq[st:st + W]
        print(f">{name}\n{motif}")

    print(f"\nBest motif score F = {F}")

    # build gapped motif MSA
    gapped_lines = []
    for name, seq, st in zip(names, sequences, starts):
        left = "-" * st
        motif = seq[st: st + W]
        right = "-" * (len(seq) - st - W)
        gapped_seq = left + motif + right
        gapped_lines.append((name, gapped_seq))

    # writing gapped motif local MSA to fasta file
    with open("gibbs_aligned.fasta", "w") as fout:
        for name, gseq in gapped_lines:
            fout.write(f">{name}\n{gseq}\n")

    print("\nWrote gapped motif alignment to gibbs_aligned.fasta")